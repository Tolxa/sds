INSERT INTO chats (user_id, chat)
VALUES (?, ?)