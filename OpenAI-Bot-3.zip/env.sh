#!/bin/bash

# Discord variables
export DISCORD_TOKEN="INSERT"
export CLIENT_ID="INSERT"
export GUILD_ID="INSERT"

# OpenAI variables
export OPENAI_API_KEY="INSERT"

# Server variables
export ADMIN_KEY="INSERT"


export PORT="INSERT"
