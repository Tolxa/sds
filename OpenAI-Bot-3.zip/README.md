# OpenAI - Discord Bot

> Demo & Tutorial: [Watch](https://youtu.be/jCfXjc2kNjI)